import './App.css'
import { useState } from 'react' 
import jacket from "./assets/jacket.jpg";
import hoodie from "./assets/hoodie.jpg";
import cardigan from "./assets/cardigan.jpg";
import shirt from "./assets/shirt.jpg";
import sweater from "./assets/sweater.jpg";
import jeans from "./assets/jeansmen.jpg";


function Product({ title, price, category, image }) {
return (
<div className="product-card">
<img src={image} alt={title} className="product-image" />
<h3>{title}</h3>
<p>Price: ${price}</p>
<p>Category: {category}</p>
</div>
);
}

function App() {
const [count, setCount] = useState(0)
const products=[
  
  {
    id:1,
    title:"Jacket",
    price:199,
    category:"Women's Clothing",
    image: jacket
  },
  {
    id:2,
    title:"Hoodie",
    price:29.99,
    category:"Men's Clothing" ,
    image: hoodie 
  },
  {
    id:3,
    title:"Cardigan",
    price:45.99,
    category:"Women's Clothing",
    image: cardigan
  },
  {
    id:4,
    title:"Shirt",
    price:29.99,
    category:"Men's Clothing",
    image: shirt},
  {
    id:5,
    title:"Sweater",
    price:49.99,
    category:"Women's Clothing",
    image: sweater
  },
  {
    id:6,
    title:"Jeans",
    price:49.99,
    category:"Men's Clothing",
    image: jeans
  }
]
const[productData,setProductData]=useState(products)
console.log(productData)
  return (
    <div className="products">
      {/* <button onClick={()=>setProductData(prev=>[...prev, {id:6, title:"New Product", price:200, category:"New Category", image:""}])}>Add Product</button> */}
    {productData.map((product) => (
      <Product
        key={product.id}
        title={product.title}
        price={product.price}
        category={product.category}
        image={product.image}
      />
    ))}
  </div>
  )
}






export default App
